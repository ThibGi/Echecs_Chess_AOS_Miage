var xmlhttp;
xmlhttp = new XMLHttpRequest();
//var address = "http://fr.teebbo.com:8080/echecs";
var address = "http://localhost:8080/AOSechecs";

function sendCoord(coord) {
        var game = document.querySelector("#game");
        var url = address + "/webresources/echec/play/" + coord.toString();
        xmlhttp.open('GET',url,true);
        xmlhttp.send(null);
        xmlhttp.onreadystatechange = function() {
         
               if (xmlhttp.readyState == 4) {
                 if ( xmlhttp.status == 200) {
                    var resp = eval( "(" +  xmlhttp.responseText + ")");
                    game.innerHTML = resp.html;
                    if (resp.echec != null) {
                        alert(resp.echec);
                    }
                 }
                 else {
                    alert("Error ->" + xmlhttp.responseText);
                 }
              }
        };
}

function refresh() {
        var game = document.querySelector("#game");
        var status = "begin";
        var url = address + "/webresources/echec/status/begin";
        xmlhttp.open('GET',url);
        //xmlhttp.setRequestHeader('Access-Control-Allow-Origin', '*');
        //xmlhttp.setRequestHeader('Access-Control-Allow-Methods', 'GET');
        xmlhttp.send(null);
        xmlhttp.onreadystatechange = function() {
         
               if (xmlhttp.readyState == 4) {
                  if ( xmlhttp.status == 200) {
                       var det = eval( "(" +  xmlhttp.responseText + ")");
                       //Dessin de l'échuiquier
                       game.innerHTML = det.html;
                       
                       //Positionnement de l'échiquier
                       var dimensions = det.zoom;
                       game.style.width = (dimensions * 8).toString() + "px";
                       game.style.height = (dimensions * 8).toString() + "px";
                       game.style.margin =  "0 auto";
                       game.style.left =  "0px";
                       game.style.right=  "0px";
                       
                 }
                 else {
                       alert("Error ->" + xmlhttp.responseText);
                 }
              }
        };
    }  

function SetOption(option) {
        var game = document.querySelector("#game");
        var url = address + "/webresources/echec/options/" + option;
        xmlhttp.open('GET',url,true);
        xmlhttp.send(null);
        xmlhttp.onreadystatechange = function() {
               if (xmlhttp.readyState == 4) {
                  if ( xmlhttp.status == 200) {
                       var det = eval( "(" +  xmlhttp.responseText + ")");
                        //alert(det.test);
                       if (det.html != null) {
                           game.innerHTML = det.html;
                           if (det.zoom != null) {
                           var dimensions = det.zoom;
                               game.style.width = (dimensions * 8).toString() + "px";
                               game.style.height = (dimensions * 8).toString() + "px";
                           }
                            /*game.style.margin =  "0 auto";
                            game.style.left =  "0px";
                            game.style.right=  "0px";*/
                       }
                       if (det.aide != null) {
                            if (det.aide == "true") {
                                document.querySelector("#aide").innerHTML = "Masquer aide";
                            } else {
                                document.querySelector("#aide").innerHTML = "Afficher aide";
                            }
                        }
                       
                 }
                 else {
                       alert("Error ->" + xmlhttp.responseText);
                 }
              }
        };
}

function createDialog(option) {
        var url = address + "/webresources/echec/dialog/" + option.toLowerCase();
        xmlhttp.open('GET',url,true);
        xmlhttp.send(null);
        xmlhttp.onreadystatechange = function() {
               if (xmlhttp.readyState == 4) {
                  if (xmlhttp.status == 200) {
                       var det = eval( "(" +  xmlhttp.responseText + ")");
                       if (det.dialog != null) {
                            createDialogContent(option, det.dialog);
                       }
                       
                 }
                 else {
                    createDialogContent("Error ->" + xmlhttp.responseText);
                 }
              }
        };
}

function createDialogContent(titre, dialogContent) {
    var sTitle = titre;
    var sHTML = dialogContent;
    
    switch(titre.toLowerCase()) {
        case "save":
                sTitle = "Sauvegarder";
            break;
         case "load":
                sTitle = "Charger";
            break;    
        case "joinmultiplayer":
                sTitle = "Rejoindre une partie multijoueur";
            break;
    }
    
    closeDiv('shadow');
    closeDiv('dialog');
    var dialog = document.createElement("div");
    dialog.innerHTML = "<div id='shadow' class='shadow'></div>"
    + "<div id='dialog' class='dialog' style='left:394px;top:272px'>"
    + "     <div class='dialogtitle' onmousedown=" + "dragId='dialog';onMouseDown(event)" + " onMouseover='isMouseover=true;' onMouseout='isMouseover=false;' onMouseMove='onMouseMove(event);'>"
    + "        <table border='0' width='100%' height='35' cellspacing='0' cellpadding='2'>"
    + "           <tr>"
    + "              <td style='cursor:move' width='100%'>"
    + "                  <div width='100%' >"
    + "                  " + sTitle + ""
    + "                  </div>"
    + "              </td>"
    + "              <td>"
    + "                 <div class='close' onclick=" + "closeDiv('shadow');closeDiv('dialog')" + ">X</div>"
    + "              </td>"
    + "           </tr>"
    + "        </table>"
    + "     </div>"
    + "     <div id='dialogcontent' style='position:relative'>"
    + "        " + sHTML + ""
    + "    </div>";
    + "</div>";
    document.body.appendChild(dialog);
}

function ExecuteDialogSave() {
    var savename = document.getElementById("savebutton").value;
    if(savename != null && savename.length > 0) {
        var url = address + "/webresources/echec/executedialogsave/" + savename;
            xmlhttp.open('GET',url,true);
            xmlhttp.send(null);
            xmlhttp.onreadystatechange = function() {
                   if (xmlhttp.readyState == 4) {
                      if (xmlhttp.status == 200) {
                           var det = eval( "(" +  xmlhttp.responseText + ")");
                           if (det.dialog != null) {
                               if (det.dialog.toLowerCase() === "true") {
                                    closeDiv("shadow");
                                    closeDiv("dialog");
                               } else {
                                   alert(det.dialog);
                               }
                           }

                     }
                     else {
                        createDialogContent("Error ->" + xmlhttp.responseText);
                     }
                  }
            };
    }
}

function ExecuteDialogLoad() {
    var list = document.querySelector("#loadlist");
    var idRow = list.getAttribute("tag");
    var game = document.querySelector("#game");
    if(idRow >= 0) {
        var url = address + "/webresources/echec/executedialogload/" + idRow;
            xmlhttp.open('GET',url,true);
            xmlhttp.send(null);
            xmlhttp.onreadystatechange = function() {
                   if (xmlhttp.readyState == 4) {
                      if (xmlhttp.status == 200) {
                           var det = eval( "(" +  xmlhttp.responseText + ")");
                           if (det.loaded != null) {
                               if (det.loaded.toLowerCase() === "true") {
                                    game.innerHTML = det.html;
                                    closeDiv("shadow");
                                    closeDiv("dialog");
                               } else {
                                   alert(det.dialog);
                               }
                           }

                     }
                     else {
                        createDialogContent("Error ->" + xmlhttp.responseText);
                     }
                  }
            };
    }
}

function closeDiv(id) {
    var div = document.querySelector("#" + id);
    if (div) {
        div.parentNode.removeChild(div);
    }
}

function onRowClick(rowId) {
    var list = document.querySelector("#loadlist");
    var tagId = list.getAttribute("tag");
    if (tagId != rowId) {
        var oldselectedId = "#loadlist_" + tagId;
        var selectedId = "#loadlist_" + rowId;
        document.querySelector(selectedId).className = "selectedRow";
        list.setAttribute("tag", rowId);
        if (tagId != -1) {
            document.querySelector(oldselectedId).className = "";
        }
    }
}
// Inits
var dragId = '';
var isDragging = false;
var isMouseover = false;
var offsetX = 0;
var offsetY = 0;
var currentX = 0;
var currentY = 0;

function onMouseDown(event) {
    if (dragId != '') {
        var CurrentWindow = document.getElementById(dragId);
        offsetX = event.clientX;
        offsetY = event.clientY;
        currentX = parseInt(CurrentWindow.style.left);
        currentY = parseInt(CurrentWindow.style.top);
        isDragging = true;
    }
   
}

function onMouseMove(event) {
    if(dragId != '') {
        CurrentWindow = document.getElementById(dragId);
        if (!isDragging) {return;}
        else {
            CurrentWindow.style.left = currentX + event.clientX - offsetX + "px";
            //var menudiv = document.getElementById("RenderMenu");
            //if (parseInt(CurrentWindow.style.top) > parseInt(menudiv.offsetHeight)) {
                CurrentWindow.style.top = currentY + event.clientY - offsetY + "px";
                //}
            //document.onmouseup = Function("dragId='';isDragging=false;onMouseUp(" + CurrentWindow.id + ");");

            return false;
        }
    }
}
//document.onmouseup = function () { };
document.onmouseup = Function("dragId='';isDragging=false;");

/////////////////////////////////////////////////

//var Jeu = function () {
window.onload = function init() {
	
    function Init() {
         
        refresh();
    }
    
    Init();
}